package pjmarket.model;

import java.util.Date;

public class MemberDTO {
	private String member_id;
	private String member_pw;
	private String member_name;
	private String member_tel;
	private String member_email;
	private String member_hyu;
	private String member_stop;
	private String member_tiers;
	private Date member_date;
	private int join_state;
	private String member_domain;
	private String member_pw2;
	private String member_addr1;
	private String member_addr2;
	private String member_tel2;
	private String member_tel3;
	private String member_phone3;
	private String member_phone2;
	private String member_phone;
	private String member_profile1;
	private String member_zip1;
	
	//추가 된 컬럼
	private int member_no;
	
	
	
	public int getMember_no() {
		return member_no;
	}
	public void setMember_no(int member_no) {
		this.member_no = member_no;
	}
	public String getMember_id() {
		return member_id;
	}
	public void setMember_id(String member_id) {
		this.member_id = member_id;
	}
	public String getMember_pw() {
		return member_pw;
	}
	public void setMember_pw(String member_pw) {
		this.member_pw = member_pw;
	}
	public String getMember_name() {
		return member_name;
	}
	public void setMember_name(String member_name) {
		this.member_name = member_name;
	}
	public String getMember_tel() {
		return member_tel;
	}
	public void setMember_tel(String member_tel) {
		this.member_tel = member_tel;
	}
	public String getMember_email() {
		return member_email;
	}
	public void setMember_email(String member_email) {
		this.member_email = member_email;
	}
	public String getMember_hyu() {
		return member_hyu;
	}
	public void setMember_hyu(String member_hyu) {
		this.member_hyu = member_hyu;
	}
	public String getMember_stop() {
		return member_stop;
	}
	public void setMember_stop(String member_stop) {
		this.member_stop = member_stop;
	}
	public String getMember_tiers() {
		return member_tiers;
	}
	public void setMember_tiers(String member_tiers) {
		this.member_tiers = member_tiers;
	}
	public Date getMember_date() {
		return member_date;
	}
	public void setMember_date(Date member_date) {
		this.member_date = member_date;
	}
	public int getJoin_state() {
		return join_state;
	}
	public void setJoin_state(int join_state) {
		this.join_state = join_state;
	}
	public String getMember_domain() {
		return member_domain;
	}
	public void setMember_domain(String member_domain) {
		this.member_domain = member_domain;
	}
	public String getMember_pw2() {
		return member_pw2;
	}
	public void setMember_pw2(String member_pw2) {
		this.member_pw2 = member_pw2;
	}
	public String getMember_addr1() {
		return member_addr1;
	}
	public void setMember_addr1(String member_addr1) {
		this.member_addr1 = member_addr1;
	}
	public String getMember_addr2() {
		return member_addr2;
	}
	public void setMember_addr2(String member_addr2) {
		this.member_addr2 = member_addr2;
	}
	public String getMember_tel2() {
		return member_tel2;
	}
	public void setMember_tel2(String member_tel2) {
		this.member_tel2 = member_tel2;
	}
	public String getMember_tel3() {
		return member_tel3;
	}
	public void setMember_tel3(String member_tel3) {
		this.member_tel3 = member_tel3;
	}
	public String getMember_phone3() {
		return member_phone3;
	}
	public void setMember_phone3(String member_phone3) {
		this.member_phone3 = member_phone3;
	}
	public String getMember_phone2() {
		return member_phone2;
	}
	public void setMember_phone2(String member_phone2) {
		this.member_phone2 = member_phone2;
	}
	public String getMember_phone() {
		return member_phone;
	}
	public void setMember_phone(String member_phone) {
		this.member_phone = member_phone;
	}
	public String getMember_profile1() {
		return member_profile1;
	}
	public void setMember_profile1(String member_profile1) {
		this.member_profile1 = member_profile1;
	}
	public String getMember_zip1() {
		return member_zip1;
	}
	public void setMember_zip1(String member_zip1) {
		this.member_zip1 = member_zip1;
	}

	
}
