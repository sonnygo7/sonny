package pjmarket.model;

public class Options {

	private int options_num;
	private int product_num;
	private String options_name;
	private int options_price;
	private int options_sale;
	
	public int getOptions_num() {
		return options_num;
	}
	public void setOptions_num(int options_num) {
		this.options_num = options_num;
	}
	public int getProduct_num() {
		return product_num;
	}
	public void setProduct_num(int product_num) {
		this.product_num = product_num;
	}
	public String getOptions_name() {
		return options_name;
	}
	public void setOptions_name(String options_name) {
		this.options_name = options_name;
	}
	public int getOptions_price() {
		return options_price;
	}
	public void setOptions_price(int options_price) {
		this.options_price = options_price;
	}
	public int getOptions_sale() {
		return options_sale;
	}
	public void setOptions_sale(int options_sale) {
		this.options_sale = options_sale;
	}
	
	
	
}
