package pjmarket.model;

public class LikeList {

	private int likes_num;
	private String member_id;
	private int product_num;
	private String product_img;
	private String product_name;
	private int product_price;
	private String options_name;
	private int options_price;
	private int options_num;
	
	public int getLikes_num() {
		return likes_num;
	}
	public void setLikes_num(int likes_num) {
		this.likes_num = likes_num;
	}
	public String getMember_id() {
		return member_id;
	}
	public void setMember_id(String member_id) {
		this.member_id = member_id;
	}
	public int getProduct_num() {
		return product_num;
	}
	public void setProduct_num(int product_num) {
		this.product_num = product_num;
	}
	public String getProduct_img() {
		return product_img;
	}
	public void setProduct_img(String product_img) {
		this.product_img = product_img;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public int getProduct_price() {
		return product_price;
	}
	public void setProduct_price(int product_price) {
		this.product_price = product_price;
	}
	public String getOptions_name() {
		return options_name;
	}
	public void setOptions_name(String options_name) {
		this.options_name = options_name;
	}
	public int getOptions_price() {
		return options_price;
	}
	public void setOptions_price(int options_price) {
		this.options_price = options_price;
	}
	public int getOptions_num() {
		return options_num;
	}
	public void setOptions_num(int options_num) {
		this.options_num = options_num;
	}
	
	
}
