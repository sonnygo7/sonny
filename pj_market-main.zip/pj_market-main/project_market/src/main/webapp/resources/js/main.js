var swiper = new Swiper(".mySwiper", {
	slidesPerView: 3,
	loop: true,
	scrollbar: {
		el: ".swiper-scrollbar",
		hide: true,
	},
});